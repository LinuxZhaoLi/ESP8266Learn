/*
 * copyright (c) 2010 - 2011 espressif system
 */

#include "c_types.h"
#include "ets_sys.h"
#include "osapi.h"
#include "os_type.h"

#include "lwip/opt.h"
#include "lwip/sys.h"

#include "eagle_soc.h"
